package me.gentilpinto.businesscard.ui.theme

import androidx.compose.ui.graphics.Color

// Example of pastel colors
val PastelPink = Color(0xFFFFC1CC)
val PastelGreen = Color(0xFFB9F8D3)
val PastelBlue = Color(0xFFA7C7E7)
val PastelPurple = Color(0xFFB5AED4)
val PastelYellow = Color(0xFFF9F8A6)
